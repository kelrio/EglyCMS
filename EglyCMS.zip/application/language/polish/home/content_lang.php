<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['emptyView_message_p1'] = 'Niestety nie istnieje żadna podstrona do wyświetlenia w systemie, zgłoś to do administartora.';
$lang['emptyView_message_p2'] = 'Jeśli jesteś administatorem strony to zaloguj się do panelu zarządzania i stworz nową treść.';
$lang['emptyView_button_login'] = 'Zaloguj się';
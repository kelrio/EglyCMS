<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['controller_Panel_changeMenuElements_no_id'] = 'Niestety nie możemy odnaleść danego elementu. Prosimy odświerzyć stronę i sprobować ponownie.';
$lang['controller_Panel_changeMenuElements_not_equal_values'] = 'Dane, ktore chciano zastąpić nie są takie same jak te, ktore znajdują się w bazie. Prosimy odświerzyć stronę i sprobować ponownie.';
$lang['controller_panel_editPage_notEqualId'] = 'Wystąpił problem z odebranymi danymi. Wybrany element nie istnieje w systemie. Zaleca się powrot do poprzedniej strony i sprobować ponownie';

$lang['controller_panel_uploadImage_success'] = 'Plik został pomyślnie załadowany na serwer';
$lang['controller_panel_uploadImage_failed'] = 'Wystąpił problem z przesyłaniem pliku';
$lang['controleer_panel_updateImage_thereIsFile'] = 'Taki plik istnieje już na serwerze';

$lang['controller_panel_uploadImage_base_error'] = 'Wystąpił problem z dodaniem elementu do bazy danych';
<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['login_login'] = 'Login';
$lang['login_password'] = 'Hasło';
$lang['login_button_logining'] = 'Zaloguj';
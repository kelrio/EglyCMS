<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['user_login'] = 'Login';
$lang['user_password'] = 'Hasło';
$lang['user_password_re'] = 'Powtooorz hasło';
$lang['user_edit_article'] = 'Edycja Treści';
$lang['user_create_page'] = 'Tworzenie podstron';
$lang['user_change_setting'] = 'Zmiana ustawień';
$lang['user_change_account'] = 'Zarządzanie kontami';
$lang['user_popup_confirm_delete_account'] = 'Na pewno chcesz usunąć konto?';

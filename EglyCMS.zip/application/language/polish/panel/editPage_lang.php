<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['editPage_modal_upload_file'] = '... prześlij pliki';
$lang['editPage_modal_add_picture'] = 'Dodaj';
$lang['editPage_picture_description'] = 'Wprowadź opis obrazka';

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['layout_active_style'] = 'Wybrana paczka styli';
$lang['layout_not_selected_file'] = 'Brak wybranego pliku';
$lang['layout_button_example_view'] = 'Zobacz przykładową stronę';

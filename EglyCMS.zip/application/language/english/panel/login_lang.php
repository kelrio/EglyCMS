<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['login_login'] = 'Login';
$lang['login_password'] = 'Password';
$lang['login_button_logining'] = 'Log in';
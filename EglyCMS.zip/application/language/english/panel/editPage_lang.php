<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['editPage_modal_upload_file'] = '... choose a file';
$lang['editPage_modal_add_picture'] = 'Add';
$lang['editPage_picture_description'] = 'Set the description of the picture';

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['layout_active_style'] = 'Selected style';
$lang['layout_not_selected_file'] = 'The selected picture does not exist';
$lang['layout_button_example_view'] = 'Open the sample page';

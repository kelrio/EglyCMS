<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['user_login'] = 'Login';
$lang['user_password'] = 'Password';
$lang['user_password_re'] = 'Replace password';
$lang['user_edit_article'] = 'Content editing';
$lang['user_create_page'] = 'Creating subpage';
$lang['user_change_setting'] = 'Change settings';
$lang['user_change_account'] = 'Management users';
$lang['user_popup_confirm_delete_account'] = 'Are you sure you want to delete your account?';

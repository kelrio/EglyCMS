<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['emptyView_message_p1'] = 'Unfortunately, there is no subpage to display in the system, please report it to the admin';
$lang['emptyView_message_p2'] = 'If you are the website administrator, log in to the management panel and create new content';
$lang['emptyView_button_login'] = 'Log in';